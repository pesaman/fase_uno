class User < ActiveRecord::Base
# Implementa los métodos y validaciones de tu modelo aquí. 

end
