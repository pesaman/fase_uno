class TasksView
	# Recuerda que la única responsabilidad de la vista es desplegar data al usuario

	def index
	end

  def create
  end

  def delete
  end

  def update
  end

	def error
	end
end
