class Flight < ActiveRecord::Base
 
end

# class User 
# end

# class Booking
# end

# class UserBooking
# end

# class UserFlight
# end