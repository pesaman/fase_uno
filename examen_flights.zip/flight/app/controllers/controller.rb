class Controller 
  def initialize(args)
    @view = View.new
  end

  def index
    # TIP: Aquí debes de llamar al método del mismo nombre de @view
  end

  def add
  
  end

  def delete
  end

  def complete
  end
end
