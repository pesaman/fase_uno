class View
	# Recuerda que la única responsabilidad de la vista es desplegar data al usuario
  # Los siguientes métodos son sólo un ejemplo:
  
	def index
	end

  def create
  end

  def delete
  end

  def update
  end

	def error
	end
end
