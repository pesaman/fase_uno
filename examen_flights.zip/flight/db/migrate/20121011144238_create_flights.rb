class CreateFlights < ActiveRecord::Migration
  def change
    create_table :flights do |t|
      # Completa con las columnas que necesites
    end

    create_table :users do |t|
    	# Completa con las columnas que necesites
    end

    #crea las tablas restantes
  end
end
