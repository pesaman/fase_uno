require_relative 'config/application'

Controller.new(ARGV)
